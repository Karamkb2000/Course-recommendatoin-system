package com.example.student_courses_recumandation_system;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class last_semester extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.last_semester);
    }
}