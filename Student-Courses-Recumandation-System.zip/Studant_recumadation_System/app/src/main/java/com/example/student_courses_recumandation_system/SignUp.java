package com.example.student_courses_recumandation_system;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignUp extends AppCompatActivity {
    EditText username,password,repassword,phone_number,email_1,fullname;
    Button signup;
    DB_helper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();//this line hides the action bar
        setContentView(R.layout.singup);

        username = findViewById(R.id.username);
        repassword = findViewById(R.id.repassword);
        password = findViewById(R.id.password2);
        signup = findViewById(R.id.signup_main);
        fullname = findViewById(R.id.fullname);
        phone_number = findViewById(R.id.phone);

        DB=new com.example.student_courses_recumandation_system.DB_helper(this);
        signup.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                String user = username.getText().toString();
                String pass = password.getText().toString();
                System.out.println("string");
                String phone = phone_number.getText().toString();
                String email = email_1.getText().toString();
                String name = fullname.getText().toString();
                String repass = repassword.getText().toString();

                if (TextUtils.isEmpty(user) || TextUtils.isEmpty(pass) || TextUtils.isEmpty(repass)|| TextUtils.isEmpty(phone)|| TextUtils.isEmpty(email)|| TextUtils.isEmpty(name))
                {
                    Toast.makeText(SignUp.this, "All fields Required", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (email.contains("@") & phone.length() == 10)
                    {
                        if (pass.equals(repass) & (pass.length() >= 8))
                        {
                            boolean checkuser = DB.checkusername(user);
                            if (checkuser == false)
                            {
                                Boolean insert = DB.insertData(user, pass, phone);
                                if (insert == true)
                                {
                                    Toast.makeText(SignUp.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                                    Intent intent1 = new Intent(getApplicationContext(), MainActivity.class);
                                    startActivity(intent1);
                                } else
                                {
                                    Toast.makeText(SignUp.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                                }
                            } else
                            {
                                Toast.makeText(SignUp.this, "User already Exists", Toast.LENGTH_SHORT).show();
                            }

                        } else
                        {
                            Toast.makeText(SignUp.this, "Password are not matching or incorrect pass=length 8 char start with uppercase", Toast.LENGTH_SHORT).show();
                        }
                    }else
                    {
                        Toast.makeText(SignUp.this, "Pleas inter valid Email and Phone number", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
    }

}