package com.example.student_courses_recumandation_system;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class semester_rate extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.semester_rate);
    }
}