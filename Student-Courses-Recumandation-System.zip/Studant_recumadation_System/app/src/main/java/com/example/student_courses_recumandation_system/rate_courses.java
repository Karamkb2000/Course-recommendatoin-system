package com.example.student_courses_recumandation_system;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class rate_courses extends AppCompatActivity implements ItemClickListener {
    RecyclerView recycler_view;
    RecyclerView recyclerview;
    QuantityAdapter2 adapter;
    ItemClickListener itemClickListener;
    ArrayList<String> arrayList_rate = new ArrayList<>();
    ArrayList<String> restult;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();//this line hides the action bar
        setContentView(R.layout.rate_courses);


        restult = getIntent().getStringArrayListExtra("list");
        TextView show = findViewById(R.id.show);
        show.setText(String.valueOf(restult));

        recycler_view = findViewById(R.id.recycleview_rate);
        recyclerview = findViewById(R.id.recycleview_rate);

        for(int i=0;i< restult.size()-1;i++){
            arrayList_rate.add("please rate the hard of thes majore:"+String.valueOf(restult.get(i)));
        }
        itemClickListener = new ItemClickListener()
        {
            @Override
            public void onClick(String s) {
                recyclerview.post(new Runnable() {
                    @Override
                    public void run() {
                        adapter.notifyDataSetChanged();
                    }
                });
                Toast.makeText(getApplicationContext(),"dfsd"+s,Toast.LENGTH_SHORT).show();
            }
        };
        recyclerview.setLayoutManager(new LinearLayoutManager(this));
        adapter = new QuantityAdapter2(arrayList_rate,itemClickListener);
        recyclerview.setAdapter(adapter);
    }


    @Override
    public void onClick(String s) {

    }
}