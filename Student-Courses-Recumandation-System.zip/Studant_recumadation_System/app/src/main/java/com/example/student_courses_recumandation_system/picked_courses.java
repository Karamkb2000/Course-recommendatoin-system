package com.example.student_courses_recumandation_system;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.NumberPicker;

public class picked_courses extends AppCompatActivity {
    NumberPicker numberPicker;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();//this line hides the action bar

        setContentView(R.layout.picked_courses);

        numberPicker = findViewById(R.id.numberPicker_free);
        numberPicker.setMinValue(1);
        numberPicker.setMaxValue(5);

        numberPicker = findViewById(R.id.numberPicker_mandatory);
        numberPicker.setMinValue(1);
        numberPicker.setMaxValue(7);
    }
}