package com.example.student_courses_recumandation_system;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class suggestion_courses extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.suggestion_courses);
    }
}