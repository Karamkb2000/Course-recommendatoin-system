package com.example.student_courses_recumandation_system;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class student_regester extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_regester);
    }
}