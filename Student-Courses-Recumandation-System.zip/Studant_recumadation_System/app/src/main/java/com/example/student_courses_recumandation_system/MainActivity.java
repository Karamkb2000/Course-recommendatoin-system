package com.example.student_courses_recumandation_system;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    String user,pass;
    EditText username,password;
    Button signup,login;
    DB_helper DB;
    static String USERNAME="";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();//this line hides the action bar
        setContentView(R.layout.activity_main);

        //get id for all fields
        username=findViewById(R.id.username1);
        password=findViewById(R.id.password1);
        signup=findViewById(R.id.signup_main);
        login =findViewById(R.id.login);
        DB = new DB_helper(this);
        // action to open the signup page
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent= new Intent(getApplicationContext(),SignUp.class);
                startActivity(intent);
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                user=username.getText().toString();
                pass=password.getText().toString();
                System.out.println(user);
                System.out.println(pass);
                if(TextUtils.isEmpty(user)|| TextUtils.isEmpty(pass))
                    Toast.makeText(MainActivity.this,"All fields Required",Toast.LENGTH_SHORT).show();
                else
                {

                    Boolean checkuserpass = DB.checkusernamepassword(user,pass);
                    System.out.println(checkuserpass);
                    if(checkuserpass==true)
                    {
                        Toast.makeText(MainActivity.this,"Login Successful",Toast.LENGTH_SHORT).show();
                        MainActivity.USERNAME=user;
                        Intent intent= new Intent(getApplicationContext(),courses_taken.class);
                        startActivity(intent);
                    }else
                    {
                        Toast.makeText(MainActivity.this,"Login failed",Toast.LENGTH_SHORT).show();
                    }
                }
            }

        });

    }
}