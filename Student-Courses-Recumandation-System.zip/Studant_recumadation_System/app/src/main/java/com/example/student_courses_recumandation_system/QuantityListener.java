package com.example.student_courses_recumandation_system;

import java.util.ArrayList;

public interface QuantityListener {
    Void onQuantityChange (ArrayList<String> arrayList);
}
