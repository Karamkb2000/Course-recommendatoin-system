package com.example.student_courses_recumandation_system;

public interface ItemClickListener {
    void onClick(String s);
}
