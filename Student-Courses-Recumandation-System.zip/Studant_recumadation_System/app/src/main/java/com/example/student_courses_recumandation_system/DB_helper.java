package com.example.student_courses_recumandation_system;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DB_helper extends SQLiteOpenHelper
{
    public static final String DBNAME="login1.db";

    public DB_helper(Context context)
    {
        super(context, "login1.db", null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db)
    {

        db.execSQL("create table users(username TEXT primary key ,password TEXT, phoneNumber TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("drop table if exists users");
        //db.execSQL("drop table if exists books");
    }
    public boolean insertData(String username,String password, String phoneNumber)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("username",username);
        values.put("password",password);
        values.put("phoneNumber",phoneNumber);
        long result = db.insert("users",null,values);
        if(result==-1)return false;
        else
            return true;

    }
    public boolean checkusername(String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from users where username=?", new String[]{username});

        if(cursor.getCount()>0)
            return true;
        else
            return false;

    }
    public boolean checkusernamepassword(String username,String password)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from users where username=? and password=?", new String[]{username,password});

        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
}











