package com.example.student_courses_recumandation_system;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import java.util.ArrayList;

public class courses_taken extends AppCompatActivity implements QuantityListener {
    RecyclerView recycler_view;
    QuantityAdapter adapter;
    Button submit;
    ArrayList<String> arrayList_checked = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();//this line hides the action bar
        setContentView(R.layout.courses_taken);

        submit = findViewById(R.id.submit);

        recycler_view = findViewById(R.id.recycleview_check);
        setRecyclerView();

    }

    public ArrayList<String> getQuantityData() {
        ArrayList<String> arrayList = new ArrayList<>(0);
        arrayList.add("CIS 101");
        arrayList.add("CS 111");
        arrayList.add("CS 210");
        arrayList.add("CS 241");
        arrayList.add("CS 241");
        arrayList.add("CS 241");
        arrayList.add("CS 241");
        arrayList.add("CS 241");
        arrayList.add("CS 241");
        arrayList.add("CS 241");
        arrayList.add("CS 241");
        arrayList.add("CS 241");
        arrayList.add("CS 241");
        arrayList.add("CS 241");
        arrayList.add("CS 241");
        arrayList.add("CS 241");
        arrayList.add("CS 241");
        arrayList.add("CS 241");
        arrayList.add("CS 241");
        return arrayList;

    }

    public void setRecyclerView() {
        recycler_view.setHasFixedSize(true);
        recycler_view.setLayoutManager(new LinearLayoutManager(this));
        adapter = new QuantityAdapter(this, getQuantityData(), this);
        recycler_view.setAdapter(adapter);
    }

    @Override

    public Void onQuantityChange(ArrayList<String> arrayList) {
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                arrayList_checked = arrayList;
                Intent intent= new Intent(getApplicationContext(),rate_courses.class);
                intent.putExtra("list",arrayList_checked);
                startActivity(intent);

            }
        });
        System.out.println(arrayList);
        Toast.makeText(this, arrayList.toString(), Toast.LENGTH_LONG).show();
        return null;
    }
}