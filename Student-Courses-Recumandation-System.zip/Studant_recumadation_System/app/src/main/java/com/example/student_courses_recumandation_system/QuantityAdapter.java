package com.example.student_courses_recumandation_system;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class QuantityAdapter extends RecyclerView.Adapter<QuantityAdapter.ViewHolder> {
    View view;
    Context context;
    ArrayList<String> arrayList;
    QuantityListener quantityListener;
    ArrayList<String> arrayList_0 = new ArrayList<>();

    public QuantityAdapter(Context context, ArrayList<String> arrayList, QuantityListener quantityListener) {
        this.context = context;
        this.arrayList = arrayList;
        this.quantityListener = quantityListener;
    }

    public View getView() {
        return view;
    }

    @NonNull
    @Override
    public QuantityAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        view = LayoutInflater.from(context).inflate(R.layout.rv_layout,parent,false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull QuantityAdapter.ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        if(arrayList != null && arrayList.size()>0){
            holder.check_Box.setText(arrayList.get(position));
            holder.check_Box.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(holder.check_Box.isChecked()){
                        arrayList_0.add(arrayList.get(position));
                    }else{
                        arrayList_0.remove(arrayList.get(position));
                    }
                    quantityListener.onQuantityChange(arrayList_0);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        CheckBox check_Box;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            check_Box = itemView.findViewById(R.id.checkBox1);
        }
    }
}
